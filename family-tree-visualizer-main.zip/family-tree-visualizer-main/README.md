# 🌳 Family Tree Visualizer (Python + Tkinter)

A **Python-based Family Tree Management System** that allows users to create, query, and visualize family relationships using a **command-line interface (CLI)** and a **graphical tree diagram built with Tkinter**.

This project demonstrates how **tree data structures, recursion, and GUI visualization** can be combined to model hierarchical relationships in a simple and interactive way.

---

# 📌 Project Overview

The **Family Tree Visualizer** allows users to build a family hierarchy by adding parent–child relationships. Once the relationships are created, users can perform queries such as:

* Finding a person's parent
* Listing children
* Finding siblings
* Finding grandparents
* Identifying root members
* Identifying leaf members
* Visualizing the entire family tree graphically

The tree structure is stored using **Python dictionaries**, and the graphical visualization is rendered using **Tkinter Canvas**.

---

# 🧠 Key Concepts Used

This project demonstrates the following computer science concepts:

* Tree Data Structures
* Recursion
* Graph-like relationships
* Dictionary-based data storage
* Command Line Interface (CLI)
* GUI Programming with Tkinter
* Data traversal

---

# 🏗 Project Architecture

The project consists of **three main components**:

### 1️⃣ FamilyTree Class

Handles all **family relationship logic**.

Responsibilities:

* Store parent-child relationships
* Query family relations
* Manage root and leaf members

Data Structures Used:

```python
tree = {
    "John": ["Michael", "Anna"],
    "Michael": ["Emma"]
}

parent_map = {
    "Michael": "John",
    "Anna": "John",
    "Emma": "Michael"
}
```

---

### 2️⃣ TreeDrawer Class (Tkinter GUI)

Responsible for **visualizing the family tree**.

Features:

* Draw nodes as circles
* Connect parents and children with lines
* Automatically arrange children
* Highlight searched members

Each node represents a **family member** and edges represent **parent-child relationships**.

---

### 3️⃣ CLI Chatbot Interface

A **command-line interactive system** where users can enter commands to manipulate and query the family tree.

Example commands:

```
add Parent Child
parent of Name
children of Name
siblings of Name
grandparent of Name
leaf
root
show
search Name
exit
```

---

# 🖥 Example Console Interaction

```
PS E:\python family_tree_app.py> python family_tree_bst_view.py

========================================
 FINAL FAMILY TREE PROJECT (Core Python)
========================================

Commands:
 add Parent Child
 parent of Name
 children of Name
 siblings of Name
 grandparent of Name
 leaf
 root
 show
 search Name
 exit

>> add John Michael
Added: Michael as child of John

>> add John Anna
Added: Anna as child of John

>> add Michael Emma
Added: Emma as child of Michael

>> show
Opening Family Tree Diagram...
```

---

# 🌳 Example Family Tree Diagram

The Tkinter interface visually renders the family hierarchy.

Example structure generated from the commands above:

```
        John
       /   \
   Michael  Anna
      |
     Emma
```

Nodes are displayed as circles and connected using parent-child edges.

---

# 🖼 Visualization Output

The graphical interface displays the tree like this:

* Parent nodes appear above children
* Each generation appears one level below
* Lines connect parents to children
* Searched nodes are highlighted

---

# ⚙️ Installation

### 1️⃣ Clone the Repository

```bash
git clone https://github.com/shivam-9s/family-tree-visualizer.git
```

### 2️⃣ Navigate to Project Folder

```bash
cd family-tree-visualizer
```

### 3️⃣ Run the Program

```bash
python family_tree_bst_view.py
```

---

# 🧪 Example Commands

### Add family members

```
add John Michael
add John Anna
add Michael Emma
```

### Find parent

```
parent of Emma
```

### Find children

```
children of John
```

### Find siblings

```
siblings of Michael
```

### Find grandparent

```
grandparent of Emma
```

### Show leaf members

```
leaf
```

### Show root members

```
root
```

### Display tree visualization

```
show
```

### Highlight a member

```
search Emma
```

---

# 📊 How the Tree is Drawn

The tree visualization works using **recursive traversal**.

Steps:

1. Draw root node
2. Find children
3. Calculate spacing
4. Draw connecting lines
5. Recursively draw child nodes

Algorithm Complexity:

* Tree Traversal: **O(n)**
* Relationship Queries: **O(1)** using dictionaries

---

# 💻 Technologies Used

| Technology      | Purpose                    |
| --------------- | -------------------------- |
| Python          | Core programming language  |
| Tkinter         | GUI visualization          |
| Data Structures | Tree representation        |
| Recursion       | Tree traversal             |
| CLI             | Interactive command system |

---

# 🚀 Features

✔ Add family members
✔ Query relationships
✔ Identify root and leaf nodes
✔ Interactive CLI commands
✔ Graphical tree visualization
✔ Highlight searched members
✔ Recursive tree drawing

---

# 🔮 Possible Future Improvements

Some potential enhancements include:

* Saving and loading family trees
* Exporting tree diagrams as images
* Adding a full GUI interface with buttons
* Supporting multiple parents
* Drag-and-drop tree editing
* Web-based visualization using React or D3.js

---

# 🎓 Learning Outcomes

This project helps in understanding:

* Tree data structures
* Recursive algorithms
* GUI development in Python
* Hierarchical data modeling
* Interactive software design

---

# 👨‍💻 Author

**Shivam**

Python Developer | Data Science Enthusiast

---

# ⭐ If you like this project

Give the repository a **star ⭐** and feel free to contribute!

---
